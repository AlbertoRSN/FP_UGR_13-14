/*
Se dice que un número es triangular si se puede poner como la suma de los primeros m valores enteros,
 para algún valor de m. Por ejemplo, 6 es triangular ya que 6 = 1 + 2 + 3. Una forma de obtener los
 números triangulares es a través de la fórmula n(n + 1)/ 2 ∀n ∈ N. Se pide construir un programa que
 obtenga todos los números triangulares que hay menores que un entero k introducido desde teclado,
 sin aplicar la fórmula anterior. Diﬁcultad Baja
*/

#include <iostream>

using namespace std;

int main()
{
    int k,

    do{
        cout<<"Introduce un entero: ";
        cin>>k;
    }while(k<=0);

    for(int i=1; i<=k; ++){


    }

}
