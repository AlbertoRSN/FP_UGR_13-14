////////////////////////////////////////////////////////////////////////////
//
// Fundamentos de Programaci�n
// ETS Inform�tica y Telecomunicaciones
// Universidad de Granada
// Departamento de Ciencias de la Computaci�n e Inteligencia Artificial
// Autor: Juan Carlos Cubero
//
////////////////////////////////////////////////////////////////////////////

/*
Una empresa que tiene tres sucursales decide llevar la contabilidad de las ventas
de sus productos a lo largo de una semana. Para ello registra cada venta con tres
n�meros, el identificador de la sucursal (1,2 � 3), el c�digo del producto (1, 2 � 3) y
el n�mero de unidades vendidas. Dise�ar un programa que lea desde el teclado una
serie de registros compuestos por sucursal, producto, unidades y diga cu�l
es la sucursal que m�s productos ha vendido. La serie de datos termina cuando la
sucursal introducida vale -1. Por ejemplo, con la serie de datos
1 2 10
1 2 4
1 1 1
1 1 1
1 3 2
2 2 15
2 2 6
2 1 20
3 3 40
-1
Se puede ver que la sucursal que m�s productos ha vendido es la n�mero 2 con
41 unidades totales. La salida del programa deber� seguir exactamente el siguiente
formato:

SUCURSAL: 2
VENTAS: 41

Para comprobar que el programa funciona correctamente, cread un fichero de texto y
re-dirigid la entrada a dicho fichero.
*/


#include <iostream> 
#include <string>  
using namespace std;   
    
int main(){  	
	const int TERMINADOR = -1;  
	const int ID_1 = 1; 
	const int ID_2 = 2; 
	const int ID_3 = 3; 
   int identif_sucursal,  identif_sucursal_max_ventas, cod_producto, unidades_vendidas;
   int num_ventas_1, num_ventas_2, num_ventas_3, num_max_ventas;
   string mensaje_entrada;
   
   mensaje_entrada = "\nSe procede a leer datos del fichero ... \n";
   cout << mensaje_entrada;
   
   num_max_ventas = 0;
	num_ventas_1 = 0;
	num_ventas_2 = 0;
	num_ventas_3 = 0;
   identif_sucursal_max_ventas = 0;   // Por si no se introduce ninguna sucursal v�lida   
   
   /* Algoritmo:
      
      Mientras que la sucursal sea distinto a TERMINADOR
         Leer datos de la sucursal
         Actualizar n�mero de unidades vendidas de la sucursal que se haya introducido
		
		Calcular el M�ximo
   */

   cin >> identif_sucursal;     
   
   while (identif_sucursal != TERMINADOR){              
      cin >> cod_producto;
      cin >> unidades_vendidas;
      
      if (identif_sucursal == ID_1)
         num_ventas_1 = num_ventas_1 + unidades_vendidas;
      else if (identif_sucursal == ID_2)
         num_ventas_2 = num_ventas_2 + unidades_vendidas;
      else if (identif_sucursal == ID_3)
         num_ventas_3 = num_ventas_3 + unidades_vendidas;
 
		// Si identif_sucursal es distinto de 1,2,3 no actualiza ning�n num_ventas_i
      
      cin >> identif_sucursal;      
   }

	num_max_ventas = num_ventas_1;
	identif_sucursal_max_ventas = ID_1;

   if (num_ventas_2 > num_max_ventas){
      num_max_ventas = num_ventas_2;  
      identif_sucursal_max_ventas = ID_2;
   }       

   if (num_ventas_3 > num_max_ventas){
      num_max_ventas = num_ventas_3;  
      identif_sucursal_max_ventas = ID_3;
   }        
   
   cout << "\nSUCURSAL: " << identif_sucursal_max_ventas;
   cout << "\nVENTAS: " << num_max_ventas << "\n";
   
   system("pause");
}
