/*********************************************************************/
// FUNDAMENTOS DE PROGRAMACIÓN
// GRADO EN INGENIERÍA INFORMÁTICA
//
// CURSO 2014-2015
// (C) Sylvia Acid
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL
//
// Cuestion abierta del tema 2
//
/*	

	Programa que lee un entero largo y muestra en pantalla cada uno
	de los digitos que lo componen en el mismo orden de izda a dcha
	E/ 1234 S/ 1 2 3 4
	
*/
/*********************************************************************/

#include<iostream>
#include<cmath>
using namespace std;

int main(){
    long leido, numero;
    int digito=0;

    cout << "Introduzca un numero entre : ";
    cin >> leido;
    numero = (leido);
    while (numero) { // para contar los dígitos
	   digito++;
  	   numero= numero /10;
    }
    cout << "digitos :!! "<< digito<< endl;

    numero=leido;
    while(digito){
      cout << numero / (int) pow(10,digito-1);
      numero = numero % (int) pow(10,digito-1);
      digito--;
    }
    cout << endl;
    return 0;
}
