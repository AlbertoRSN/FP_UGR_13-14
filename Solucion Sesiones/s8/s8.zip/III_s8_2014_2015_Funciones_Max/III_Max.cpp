////////////////////////////////////////////////////////////////////////////
//
// Fundamentos de Programaci�n
// ETS Inform�tica y Telecomunicaciones
// Universidad de Granada
// Departamento de Ciencias de la Computaci�n e Inteligencia Artificial
// Autor: Juan Carlos Cubero
//
////////////////////////////////////////////////////////////////////////////


/*
	Cread una funci�n que calcule el m�ximo entre tres double
*/

#include <iostream>
#include <string>
using namespace std;

/*
	Dentro de una funci�n que realiza c�mputos, JAM�S leeremos los datos dentro de ella.
	Si ejecutamos cin dentro de la funci�n, �sta ya no puede usarse en un entorno (Windows por ejemplo) en
	el que no funcione cin.
	Adem�s, la funci�n no sirve para calcular el m�ximo de tres valores 
	que No vengan del teclado -perif�rico de entrada en general-
*/

double MaxSuspenso(){   // Suspenso garantizado :-(
	double max;
	double un_valor, otro_valor, el_tercero;

	cin >> un_valor;
	cin >> otro_valor;
	cin >> el_tercero;

	if (un_valor >= otro_valor)
		max = un_valor;
	else
		max = otro_valor;

	if (el_tercero >= max)
		max = el_tercero;

	return max;
}


double Max(double un_valor, double otro_valor, double el_tercero){   // :-)
	double max;

	if (un_valor >= otro_valor)
		max = un_valor;
	else
		max = otro_valor;

	if (el_tercero >= max)
		max = el_tercero;

	return max;
}



/*
int main(){
	const string MENSAJE_ENTRADA = "\nIntroduzca un valor entero ";
	double uno, dos, tres;
	double maximo_de_los_tres;

	cout << MENSAJE_ENTRADA;
	cin >> uno;
	cout << MENSAJE_ENTRADA;
	cin >> dos;
	cout << MENSAJE_ENTRADA;
	cin >> tres;

	maximo_de_los_tres = Max(uno, dos, tres);

	cout << "\nEl m�ximo es " << maximo_de_los_tres;

	cout << "\n\n";
	system("pause");
}
*/

double LeeEntero(string mensaje){
	int entero;
	
	cout << mensaje;
	cin >> entero;
	
	return entero;
}


int main(){
	const string MENSAJE_ENTRADA = "\nIntroduzca un valor entero ";
	double uno, dos, tres;
	double maximo_de_los_tres;

	uno  = LeeEntero(MENSAJE_ENTRADA);
	dos  = LeeEntero(MENSAJE_ENTRADA);
	tres = LeeEntero(MENSAJE_ENTRADA);

	maximo_de_los_tres = Max(uno, dos, tres);

	cout << "\nEl m�ximo es " << maximo_de_los_tres;

	cout << "\n\n";
	system("pause");
}


