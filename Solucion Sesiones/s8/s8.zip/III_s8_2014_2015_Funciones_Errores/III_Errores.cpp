////////////////////////////////////////////////////////////////////////////
//
// Fundamentos de Programaci�n
// ETS Inform�tica y Telecomunicaciones
// Universidad de Granada
// Departamento de Ciencias de la Computaci�n e Inteligencia Artificial
// Autor: Juan Carlos Cubero
//
////////////////////////////////////////////////////////////////////////////

#include <iostream>
using namespace std;

/*
int ValorAbsoluto (int entero) {
	if (entero < 0)
		entero = -entero;
	else
		return entero;
}
*/

int ValorAbsoluto (int entero) {
	if (entero < 0)
		entero = -entero;
	
	return entero;
}

/*
void Imprime(double a) {
   
	double a;
   cout << "\n" << a;
}
*/

void Imprime(double a) {
   cout << "\n" << a;
}

/*
void Producto (int a) {
   return a*a;
}
*/


int Producto (int a) {
   return a*a;
}

/*
bool EsPositivo(int valor) {
   if (valor > 0)
      return true;
}
*/

bool EsPositivo(int valor) {
   return (valor > 0);
}


int main(){
   Imprime(ValorAbsoluto(-14));
   Imprime(Producto(3));
	cout << "\n" << EsPositivo(-3);
   cout << "\n\n";
	system("pause");
}
